let menu = ['palak paneer','chole chawal', 'pizza', 'egg burji', 'chicken butter','daal','chicken biryani'];


function isVeg(food){
   if((food.toLowerCase().indexOf('chicken') !== -1) || (food.toLowerCase().indexOf('egg') !== -1)){
    return false;
   }
   return true;
}

let vegMenu = menu.filter(isVeg);
console.log(menu);
console.log(vegMenu);