// function step1(){
//     setTimeout(function() {
//         console.log('img select kr raha hn');
//         return 'img';
//     }, 4000);
// }



// function step2(image){
//     setTimeout(function() {
//         console.log(`beautiful ${image} photo`);
//         return 'sundar phot';
//     }, 2000);
// }



// function step3(filterimg){
//     setTimeout(function(){
//         console.log(`badiya sa caption ${filterimg}`);
//         return'futva peluss captionva dono';
//     } , 3000);
// }


// function step4(final){
//     setTimeout(function(){
//         console.log(`uploaded ${final}`);
//         return'futva peluss captionva dono';
//     } , 2000);
// }



// let image = step1();
// let filterimg = step2(image);
// let finalimg = step3(filterimg);
// step4(finalimg);




// better tarika

function step1(fn){
    setTimeout(function() {
        console.log('img select kr raha hn');
        // return 'img';
        fn('image');
    }, 4000);
}



function step2(image, fimg){
    setTimeout(function() {
        console.log(`beautiful ${image} photo`);
        // return 'sundar phot';
        fimg('sundar photo');
    }, 2000);
}

function step3(filterimg,finalimg){
    setTimeout(function(){
        console.log(`badiya sa caption ${filterimg}`);
        // return'futva peluss captionva dono';
        finalimg('badiya sa caption');
    } , 3000);
}


function step4(final){
    setTimeout(function(){
        console.log(`uploaded ${final}`);
        return'futva peluss captionva dono';
    } , 2000);
}


step1(function(image){
    step2(image , function(filterimg){
           step3(filterimg , function(finalimg){
            step4(finalimg);
           });
    });
});


// advantage of nested function -> ek function ke baad 2 function , 2 ke baad 3 function aise hi end tk


// disadvantage of nested function -> Pyramid of doom (Callback hell) -> code ka flow grows towards horizontal side
// Callback hell means Callbackke andar Callback
// dependency

// ***callback se bchne ke liye Promises aur Promises se bchne ke liye Async-Await