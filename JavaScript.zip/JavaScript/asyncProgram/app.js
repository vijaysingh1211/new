// setTimeout -> this method present inside browser.

// console.log('start');

// setTimeout(function() {
//     console.log('run after 4 secs');
// }, 4000);

// console.log('END');



console.log('start');

setTimeout(function() {
    console.log('run after 4 secs');
}, 4000);

setTimeout(function() {
    console.log('run after 2 secs');
}, 2000);

console.log('END');