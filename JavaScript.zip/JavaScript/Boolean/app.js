let va = true;
console.log(va);

let nb = false;
console.log(nb);

let one = 'true';
let two = 'false';

let ans1 = va == nb;
console.log(ans1);

let ans2 = va == one;
console.log(ans2);

console.log(two == nb);




let a = va === one;
console.log(a);

let b = va == 1; // general equality --> meaning it tries to convert values to the same type before comparing.
console.log(b);

let c = va === 1; // strict equality  -->It checks both value and type.
console.log(c);