// JQuery -> it is JS library, it helps in DOM manipulation
// when we include a jquery $ varible is access and by help of this we can manipulate DOM

// we can write JQuery(keyword) or $ working is same

// documentation ke liye --> JQuery.com -- API docs and you might not need jquery.com 




// selectors
// tag
// console.log($('h1'));
 

// // class
// console.log($('sam'));


// // id
// console.log($('vij'));


// manipulate elements

// single css property
// $('h1').css('color','red');
// $('h1').css('background-color','red');


// multiple css property
// $('h1').css({
//     color:'red',
//     backgroundColor : 'green'
// })

 
 
// access text
// console.log($('p').text());  //(getter)  text is method
// console.log($('p').text('Thomas Shelby'));  //(setter)  text is method


// console.log($('p').html());  //getter
// console.log($('p').html('<em> Thomas Shelby </em>')); //setter




//manipulating attributes
// console.log($('a').text());
// console.log($('a').attr('href'));  //getter
// console.log($('a').attr('href' , 'http://bing.com'));  //seter




// $('h1:nth-of-type(3)').css('border', '2px solid plum');
// $('h1:first()').css('border', '2px solid plum');
// $('h1:last()').css('border', '2px solid plum');




// $('h1').last().css('border', '2px solid plum'); // alternative way
// $('h1').first().css('border', '2px solid plum'); // alterntive way





// getting value of inputs

// console.log($('input').val()); //getter
// console.log($('input').val('mai nahi jaunga')); //setter





// class manipulation

// addClass()
// $('h1').first().addClass('first'); //single class
// $('h1').first().addClass('first second sam'); //multiple class

// removeClass()
// $('h1').first().removeClass('second'); //single class
// $('h1').first().removeClass('second sam'); //multiple class

// toggleCLass()
// $('h1').first().toggleClass('second'); //single class
// $('h1').first().toggleClass('second sam'); //multiple class

// hasClass() --> check the class hai ki nahi                      
// $('h1').first().hasClass('first'); //single class
// $('h1').first().hasClass('first second sam'); //multiple class





// events

// click
// $('button').click(function(){
//     console.log("gaddi pr hum rahe yaa munna niyam same rahega");
// })


// new concept and impotant
// event.target === this
// ye 'this' alg hai ('this' points to the element  over wihch the event is being tiggered)
// never use arrow function
// $('li').click(function(){
//     $(this).css('color','pink');
// });




// input

// $('input').keyup(function(){
//     console.log($(this).val());
// })




 
// addEventListener --> 'on'
 
// $('button').on('click' ,function(){
//     console.log("gaddi pr hum rahe yaa munna niyam same rahega");
// })
 
 
 
 
 
// $('input').keypress(function(e){
//     if(e.which === 13){
//         console.log($(this).val());
//     }
// })
 
 

 
 
 
// effects
$('#fadeout').click(function(){
    $('#container').fadeOut();
})           

$('#fadein').click(function(){
    $('#container').fadeIn();
})

$('#fadetoggle').click(function(){
    $('#container').fadeToggle();
})
