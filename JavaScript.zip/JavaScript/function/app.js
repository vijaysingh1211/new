
// function declaration
function sum(){
    let num1 = 10;
    let num2 = 20;
    console.log(num1+num2);
}

// function calling
sum();
sum();


// parameterized function
function triple(num3){ // parameter
    let num1 = 10;
    let num2 = 20;
    console.log(num1 + num2 + num3);
}
triple(100); //arguments
triple(10);  //arguments
triple(200); //arguments


// returning something from a function
function sum3(){
    let num1 = 10;
    let num2 = 20;
    return (num1 + num2);
}
console.log(sum3()); 



// multiple parameters
function vijay(num1,num2){
    return num1 +num2;
}
console.log(vijay(30,40));


// NAN
function vij(num1 , num2){
    return num1 + num2;
}
console.log(vij(20));


// nothing returned and less arguments
function chauhan(num1,num2){
    console.log(num1); //30
    console.log(num2); //undefined
}
console.log(chauhan(30)); //undefined



// default parameterised functions
function sam(num1, num =10){ //default parameter
   console.log(num1); //20
   console.log(num);  
}
sam(20);



// function Expression
// first class function
// first class citizen 
let funkshion =  function samsung(){
    console.log("hi samsung");
}
samsung();