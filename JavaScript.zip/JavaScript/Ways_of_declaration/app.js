// const
// const email = 'vijay@gmail.com';
// console.log(email);

// can we redeclare --> NO
// const email = 'sam@gmail.com';
// console.log(email);

// can we reassign --> NO
// email = 'sam@gmail.com';
// console.log(email);

// not possible
// const naam;
// naam = 'vijay';




// let
// let var_name = 'vijay';
// console.log(var_naam);

// can i redeclare it --> NO
// let var_name = '10001';

// can i reassign it ---> yes
// var_name = '100';
// console.log(var_name);

// possible
// let var_naam;
// var_naam = 1000;
// console.log(var_naam);




// var
// var college = true;
// console.log(college);

// can i redeclare it --> yes
// var college = false;
// console.log(college);

// can i reassign it --> yes
//  college = false;
// console.log(college);

// possible
// let var_naam;
// var college = true;
// console.log(college);

