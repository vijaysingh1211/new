// array destructuring

let fruits = ['apple','guava','mango','banana'];


// older way
let first = fruits[0];
let second = fruits[1];
console.log(first);
console.log(second);




// destructure an array
// 
let [sachin, sparsh] = fruits;

console.log(sachin);
console.log(manish);






// object destructure

let car = {
    name:'nano',
    price: 100000
}

// older way
// let n = car.name;
// let p = car.price;

// console.log(n);
// console.log(p);

// better way

// object destructuring
// let {n,p} = car;  wrong way

let {name,price} = car;   //right way
console.log(name);
console.log(price);                                                         


