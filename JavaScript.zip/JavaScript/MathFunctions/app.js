// console.log(Math.PI);
// console.log(Math.E);
// console.log(Math.LN2);
// console.log(Math.sqrt(27));
// console.log(Math.min(12,2,3,53,2));
// console.log(Math.max(23,4,2,14,4));
// console.log(Math.round(10.79));
// console.log(Math.ceil(10.1));
// console.log(Math.floor(10.9));
console.log(Math.random()); //generate value from 0 to 1 excluded 1

console.log(Math.random() * 10);

console.log(Math.floor(Math.random() * 10)); //btw 1 to 10


// let ans =Math.floor( Math.random()*6 + 22);
// console.log(ans);


// let ans =Math.floor( Math.random()*10000);
// console.log(ans);
