// constructor function
// function Person(firstname,lastname,mail){
//    this.firstname = firstname;
//    this.lastname = lastname;
//    this.email = mail;
// }
// Person.prototype.printname = function(){
//     console.log(`${this.firstname} ${this.lastname}`);
// }
// Person.prototype.getname = function(){
//     return(`my name is ${this.firstname} ${this.lastname}`);
// }

// let person1 = new Person('sam','vohra','sam@gmail.com');
// console.log(person1);
// console.log(person1.email);
// console.log(person1.printname());
// console.log(person1.getname());




// class syntax

//     class name {
//     constructor() {
            
//     }
// }



class Person{
    constructor(firstname,lastname,mail){
    this.firstname = firstname;
    this.lastname = lastname;
    this.email = mail;
    }
    getname(){
        return(`my name is ${this.firstname} ${this.lastname}`);
    }
    printname(){
         console.log(`${this.firstname} ${this.lastname}`);
    }
}
let person2 = new Person('ms','dhoni','ms@gmail.com');
console.log(person2);
console.log(person2.email);
console.log(person2.firstname);
console.log(person2.printname());
console.log(person2.getname());


class Student extends Person{
        constructor(firstname,lastname,mail,groupno){
            super(firstname,lastname,mail);
      this.group = groupno;
    }
     getname(){
        return(`superman ${this.firstname} ${this.lastname}`);
    }
}

let student1 = new Student('barack', 'obama','obama@gmail.com',100);
console.log(student1);
console.log(student1.email);
console.log(student1.group);
console.log(student1.getname());
