let arr1 = [10,20,30,40];
let arr2 = [50,60,70];

// concat
// let arr3 = arr1.concat(arr2);
// console.log(arr3);



// spread operator ---> modern way
// in array
arr2 = [...arr1,50,60,70];
console.log(arr2);




// in object
let obj = {
    l:10,
    m:'sam',
    n:'live class'
}

let obj2 = {
    ...obj,
    age:27
}

console.log(obj2);


// delete m property from obj
delete obj.m;
console.log(obj);


let arr = [0,1,2,3,,4,5,6,7,8,9];
console.log(Math.min(arr)); //NAN
console.log(Math.min(...arr)); //min value

