var a =10;

function func(){
    console.log(a);
}
func();