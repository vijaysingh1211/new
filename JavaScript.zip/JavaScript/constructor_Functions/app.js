function fun(){
    
}
let naam = fun();
 console.log(naam);



//  constructor function -> new keyword before the function calling is creating this function as constructor function whose task is to create objects.

// function user(){
//  this.username = 'sam';
//  this.email = 'vij@gmail.com';
// }

// let user1 = new user();
// console.log(user1);



function User(user,mail){
 this.username = user;
 this.email = mail;
 
}

User.prototype.description =function(){
    return `my name is ${this.username}`;
}



let user1 = new User('sam','vij@gmail.com');
let user2 = new User('coding','coding@gmail.com');
console.log(user1);
console.log(user1.description);
console.log(user2);
console.log(user2.description);

// convention -> jaroori nahi hai pr karoge toh behtar hai


