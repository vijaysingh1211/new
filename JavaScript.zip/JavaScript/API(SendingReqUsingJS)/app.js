// ways by which i can call APIS inside JS
// 1. XML HttpRequest() --> web API's
// 2. fetch() --> --> web API's
// 3. Libraries (3rd party)
// JQuery
// Axios

// XML HttpRequest() 
// let req = new XMLHttpRequest();

// // connection bana hai bascically
// req.open('GET' ,'https://inshorts.deta.dev/news?category=science' );



// // bhejni hai apni request
// req.send();


// // jb sahi salamat data mile or jb saara kaam sahi se hojae
// req.onload = function(){
// //    console.log(this);
//     let samachar  = JSON.parse(this.response);
//     // console.log(data);
//     for(let d of samachar.data){
//         let  li = document.createElement('li');
//         li.innerHTML = `
//         <img src=${d.imageUrl} height="100px" />
//         <span>${d.title}</span>
//         `
//         ul.appendChild(li);
//     }
// }
// // lekin agar error aaya to
// req.onerror = function(){
//     console.log(this);
// }
// API not working






// fetch() -> when we fetch the data , server saara data nahi bhejta(chunk of data bhejta ) usi data ko meta data or headers kehte hai.
// method bydeafault get hota hai
// fetch('https://inshorts.deta.dev/news?category=science') //returns a promise
//      .then(function(response){
//         //    console.log(response);
//         return response.json(); //.json() also returns a promise (saara data laane ke liye use hota hai)
//      })
//      .then(function(data){
//          console.log(data);
//      })
//      .catch(function(err){
//           console.log(err);
//      })






// Axios (3rd party-library)
// it also returns a promise
// isme saara data ek saath aata hai

axios.get('https://inshorts.deta.dev/news?category=automobile')
    .then(function(resp){
        console.log(resp);
    })
    .catch(function(err){
        console.log(err);
    })



