// rest parameter

function sam(a,b,c ,...nums){ // nums will be an array(and num should always be in the end)
    console.log(num);
      return a+b+c;
}

let ans = sam(1,2,3,4,5,6,7,8,9);
console.log(ans);








 