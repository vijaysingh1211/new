
// import {firstname,sum,lastname,username} from './app.js';
// console.log(firstname);
// console.log(lastname);
// console.log(username);

// sum(2,3);




// default import

import username from './app.js';

console.log(username);