// export two types
// 1. named -> always use {}
// 2. default -> no need of {}


// named
// export let firstname = 'vijay';
// export let lastname = 'singh';
// export let username = 'vijaysingh';

// export function sum(a,b){
//      console.log(a+b);
// }




// let firstname = 'vijay';
// let lastname = 'singh';
// let username = 'vijaysingh';


// function sum(a,b){
//      console.log(a+b);
// }
// export{firstname,lastname,username,sum}





// default export

let firstname = 'vijay';
let lastname = 'singh';
let username = 'vijaysingh';


function sum(a,b){
     console.log(a+b);
}
export default username;