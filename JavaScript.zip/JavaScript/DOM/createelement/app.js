// document.createElement('h1');
let paapilaal = document.createElement('div');
let foolandevi = document.createElement('div');


let arti = document.getElementById('arti');


paapilaal.innerText = 'paapi chulo';
foolandevi.innerText = 'foolandevil';
// add element

arti.appendChild(paapilaal); //it accepts html element only,only accepts one element aur end me append hoga


arti.append(paapilaal,foolandevi,'vijayd j'); //it accepts html element + text , accept multiple elements aur end me append hoga


// arti.prepend(paapilaal,foolandevi); //it accepts html element + text, accept multiple elements aur starting me add hoga





