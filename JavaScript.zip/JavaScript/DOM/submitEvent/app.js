// form default behaviour is submit itself
// form refresh browser
// let form  = document.querySelector('form');
// form.addEventListener('submit',function(event){
//     event.preventDefault(); // default behv. rok deta hai(by help of this browser not refreshed bydefault)
//     console.log("submitted");
// });





// accessing the elements in the form

let form  = document.querySelector('form');
form.addEventListener('submit',function(event){
    event.preventDefault(); 
    console.log(form.elements[0].value);
    console.log(form.elements[1].value);
});
