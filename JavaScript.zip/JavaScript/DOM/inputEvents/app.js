// whenever an event is run along function or event , an object is also attached with it which we can have access of.
let inp = document.querySelector('input');
function fun(event){ //anyname will work generally e/event
    console.log(event.target.value); //event is a object and target is jis element par event trigger hua hai, value take content from input
//    console.log("inp ele chl gya bhi lgo");
}
inp.addEventListener('input',fun);   


// task ->input content show in h1 tag
let inp1 = document.querySelector('input');
let h1 = document.querySelector('h1');

inp1.addEventListener('input',function(event){
    h1.innerText = event.target.value;
}); 