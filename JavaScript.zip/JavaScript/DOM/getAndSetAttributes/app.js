
// getAttribute -> to fetch the text/property of an attribute (1 args)
let anchor = document.querySelector('a');
console.log(anchor.getAttribute('href'));
console.log(anchor.getAttribute('class'));


// setAttribute -> to set an attribute(2 args)
let anchor1 = document.querySelector('a');
anchor.setAttribute('href', 'http://facebook.com');


// real world cases

let h1 = document.querySelector('h1');
h1.setAttribute('class','samarth');




let input  = document.querySelector('input');
// input.setAttribute('type','color');
// input.setAttribute('type','date');
// input.setAttribute('type','checkbox');
input.setAttribute('type','password');