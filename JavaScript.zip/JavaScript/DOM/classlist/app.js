let art = document.querySelector('article');

//1. add()
art.classList.add('sam','vij','tell');

art.classList.add('changu-magnu');


//2. remove()
// art.classList.remove('sam','vij');                         



// 3. toggle -> it change the property like theme(light,dark) 

art.classList.toggle('toggle');                               


// art.classList.toggle('toggle');

// art.classList.toggle('toggle');



// 4. contains ---> it returns a boolean value 

console.log(art.classList.contains('sam'));
