// events -> actions jo happens on html documents.

//inline way
// function dosomething(){
//    console.log('maine btn daba diya hai jo krna hai krlo')
// }


// let btn = document.getElementById('btn');
// console.log(btn);
// console.dir(btn);
// log ->object ko string format me print kara kr deta
// dir -> shows all the details of that object 



// 2nd way
// let btn = document.querySelector('button');

// onclick event

// btn.onclick = function(){
//     console.log("hello duniya");
// }



// mouseenter event -> when you take cursor on that tag it changed
// btn.onmouseenter = function(){
//     btn.style.color = 'red';
// }

// // mouseleave event -> when you leave cursor on that tag it changed
// btn.onmouseleave = function(){
//     btn.style.color = 'black';
// }



// eventListener -> it allows you to run multiple events listener on the same element
// let btn = document.querySelector('button');

// function one(){
//     console.log('one');
// }
// function two(){
//     console.log('two');
// }

// btn.addEventListener('click', one);
// btn.addEventListener('click', two);



// task -> btn click --> body ka bacground color = red

// let btn = document.querySelector('button');
// let bo = document.querySelector('body');
// // btn.onclick = function(){
// //     bo.style.backgroundColor = 'red';
// // }
// btn.addEventListener('click',function(){
//     bo.style.backgroundColor = 'red';
// });



// ondubleclick -> 2 baar click 
let btn = document.querySelector('button');
function meraFunc(){
    console.log("2 baar dabaya hai")
}
btn.addEventListener('dblclick' , meraFunc);