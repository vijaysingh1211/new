// setInterval -> repeat after a interval time

let arr = [
    'https://images.unsplash.com/photo-1749741326969-e1676b3bce43?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDF8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwxfHx8ZW58MHx8fHx8',
    'https://images.unsplash.com/photo-1752542362589-a5668de3b1c1?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyMHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1751385304965-1f6e26a10b43?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw0MHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1751971725935-84dd6f5e3544?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw2M3x8fGVufDB8fHx8fA%3D%3D0',
    'https://images.unsplash.com/photo-1752496134453-d7658ecfa600?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw2OXx8fGVufDB8fHx8fA%3D%3D'
]

let img = document.querySelector('img');
let n =0;
setInterval(() => {
    img.setAttribute('src',arr[n]);
    n++;
    if(n==5){
        n=0;
    }
}, 3000);