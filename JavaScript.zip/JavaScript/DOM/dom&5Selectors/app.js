// DOM -> Document object modelling(change html with the help of javascript)

// Document -> html
// modelling -> to manipulate(change)
// object -> object


// Selectors
// 1- getElementByTagName
// 2- getElemntById
// 3- getElemntByClass
// 4- querySelector (1Elemnt)
// 5- querySelectorAll(all Element)

// you can not use push/pop in dom


// 1- getElementByTagName -> it returned an array

// console.log(document.getElementsByTagName('h1'));
let h1arr = document.getElementsByTagName('h1');
console.log(h1arr[0]);
console.log(h1arr[1]);

for (let i = 0; i < h1arr.length; i++) {
  console.log(h1arr[i]);
    
}


let para = document.getElementsByTagName('p');
for (let item of para) {
//   console.log(para[item]);
    item.style.color = 'red';
    item.style.border = '2px solid black';
}




// --------------------------------------------------
// 2- getElemntById -> it returned an element

let id = document.getElementById('sam');
console.log(id);
id.style.fontsize = '70px';



//     --------------------=================

// 3- getElemntByClass  -> it returned an array

let clas = document.getElementsByClassName('dom');
console.log(clas);
for (let item of clas) {
    item.style.color = 'orange';
}



// --------------------------------------------------
// 4- querySelector (1Elemnt) -> it always return an single element

let h1 = document.querySelector('h1');
console.log(h1);

let dom = document.querySelector('.dom');
console.log(dom);

let idd = document.querySelector('#sam');
console.log(idd);



// -------------------------------------------------
// querySelectorAll -> it returned a (NodeList)Array
let h2 = document.querySelectorAll('h1');
console.log(h2);

let dom1 = document.querySelectorAll('.dom');
console.log(dom1);

let idd1 = document.querySelectorAll('#sam');
console.log(idd1);