// remove child()
let parent = document.querySelector('div');

let h1pehla = document.querySelector('h1');
let h2dusra = document.querySelector('#h1dusra');

parent.removeChild(h1pehla);



// remove()
h2dusra.remove();