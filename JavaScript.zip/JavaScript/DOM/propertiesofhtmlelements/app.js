// properties of html elements
// they are acting like getter and setter


// getters
// innerText -> it gives the text inside that tag,aware of css
let para = document.querySelector('p');
console.log(para.innerText);



// textContent -> it gives the text inside the tag,not aware of css
let para2 = document.querySelector('p');
console.log(para2.textContent);
    


// innerHtml ->it shows text and tags (attributes),most suited 
let para3 = document.querySelector('p');
console.log(para3.innerHtml);



// setters

// para3.innerHtml = "hi i am  @vijayCoder"
para3.innerHTML = "hi i am  @vijayCoder"




