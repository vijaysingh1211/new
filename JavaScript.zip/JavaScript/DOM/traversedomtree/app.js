
// 1. parentElement
let p1 = document.querySelector('#p1');
let arti1 = document.querySelector('#arti');
let div3 = document.querySelector('#div3');
console.log(p1.parentElement.parentElement.parentElement.parentElement.parentElement);




// 2. child
let coll = arti1.children;

for (let item of coll) {
    item.style.fontSize = '100px';
}


// 3. nextElementSibling

console.log(div3.nextElementSibling);



// 4. previousElementSibling
console.log(div3.previousElementSibling);





































