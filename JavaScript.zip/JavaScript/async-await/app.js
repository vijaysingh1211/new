// async function return promise
// async work always work with await


async function name() {
    await new Promise((resolve,reject) =>{
        setTimeout(() => {
            console.log('3 second hogaye');
            resolve();
        }, 3000);
    })

    await new Promise((resolve,reject)=>{
     setTimeout(()=>{
        console.log('2s hogaye');
        resolve();
     },3000)   
    })
    console.log('dono kaam hogaye');
}
name();