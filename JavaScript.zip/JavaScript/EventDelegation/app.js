let products = document.querySelectorAll('section figure');



//not the optimized way
// for (let item of products) {
//     item.addEventListener('click' , function(){
//         console.log(this.innerText);
//     });
// }



// event delegation --> parent pr evennt lagao rather then child par

let section = document.getElementById('container');

section.addEventListener('click', function(e){
    if(e.target.nodeName === 'FIGURE'){
           console.log(e.target.innerText); 
    }
});