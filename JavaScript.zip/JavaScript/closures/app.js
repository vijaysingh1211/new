// when we return a function it takes the lexical scope with it

function some(){
let username = 'vijay';
function printname(){
    console.log(username);
}
 return printname;
}
let returnvalue = some();
returnvalue();




function counter(){
    let count = 0;
    return {
    getcount : function(){
        return count;
    }
};
}
let counter1 = counter();
console.log(counter1.getcount()); // 0




// application small

function counter(){
    let count =0;
    return {
        getcount: function(){
            return count;
        },
        increment : function(){
            count+=1;
        },
        decrement : function(){
            count=0;
        },
        reset: function(){
            count=0;
        }
    };
}

let counter2 = counter();
consloe.log(counter2.getcount());
counter2.increment();
counter2.increment();
consloe.log(counter2.getcount());
counter2.decrement();
consloe.log(counter2.getcount());