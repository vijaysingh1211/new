// for loop
for (let i = 0; i <= 5; i++) {
   for (let j = 0; j <= 5; j++) {
   if(i === j){
    break;
   }
   console.log(i, j);   
}
}

// while
let a =100;
while(a>0){
    console.log(a);
    a = a - 10;
}


// for-in
let person = {
    name : 'vijay',
    age:23,
    isMale:true
}

for(let item in person){
    console.log(person[item]);
}

for(let item in person){
    console.log(`${item} --> ${person[item]}`);
}



// for-of
let arr = ['sam', 'vijay' , 'ravi'];

for(let item of arr){
    console.log(item);
}