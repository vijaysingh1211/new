
// forEach() - > we cannot return in ths
let students = ['ajay','ajita','vijay','kaushal','nitin'];

// students.forEach(function(i){
//     console.log(i);
// });

students.forEach(function(i,idx){
    console.log(i,idx);
});




// map() -->it only a array method, it accepts  a callback function , it returns a new array

let marks = [10,20,30,40,50,60];

let newmarks = marks.map(function(i,idx){
//   return 2*i;
    //  return {i,idx};
     return [i,idx];

});
console.log(newmarks);





// filter() -> it only return true values

let mark = [4,20,30,40,50,60];

let arr = mark.filter(function(i,idx){
  if(i>=5){
    console.log(idx); 
    return true; //it cannot return idx like [true,idx]=error
  }
  else{
    return false;
  }
});
console.log(arr);


// sort() -->

let data = [12,4,1,5,21,3,8,6,31];
let ard = data.sort(); //lexographically sorted
console.log(ard);

let narr = ard.sort(function(a,b){
    // return a-b;//ascending
    return b-a;//descending
});
console.log(narr);



