// promise -> tackle the callback hell
// rsolve -> .then
// reject -> .catch


// let promise = new Promise(function(resolve , reject){
//     setTimeout(function(){
//     //   let data = 'hi dosto data mil gaya';
//     //   resolve(data);
//     // let err = 'oops dikkat aa gayi';
//     // reject(err);
    

//     },3000);
// });

// promise.then(function(data){
//     console.log(data);
// }).catch(function(err){
//     console.log(err);
// });





// let p1 = new Promise((resolve , reject) =>{
//     console.log('3 second ka wait kro kaam in process..');
//        setTimeout( ()=>{
//        resolve();
//        },3000);
// });


// p1.then(()=>{
//   console.log("kaam ho gaya");
// });








// ------------------------------------

// .then() chaining problem
let p1 = new Promise((resolve,rejexxt)=>{
  console.log("3 secod ka wait kro kaam in process");
  seTimeout(()=>{
    resolve();
  },3000)
});


p1.then(()=>{
  return new Promise((resolve,reject)=>{
    console.log("promise run krdia hai intezaar kro ab");
    setTimeout(()=>{
      console.log("2 second lag gaye bhaisaab");
      resolve();
    },2000);
  })
})

.then(()=>{
  console.log("dono kaam hogaye mere");
})