let jsonData = `[
    {
      "author": "Pragya Swastik",
      "date": "15 Mar 2020,Sunday",
      "imageUrl": "https://static.getinpix.com/public/images/v1/variants/jpg/m/2020/03_mar/15_sun/img_1584273701082_423.jpg",
      "readMoreUrl": "https://www.dailymail.co.uk/tvshowbiz/article-8111761/Breaking-Bad-star-Aaron-Paul-reveals-owned-computer-decade-prefers-FLIP-PHONE.html?utm_campaign=fullarticle&utm_medium=referral&utm_source=inshorts ",
      "time": "06:17 pm",
      "url": "https://www.inshorts.com/en/news/i-use-a-dumb-phone-that-only-makes-calls-sends-texts-breaking-bad-actor-1584276455594"
    },
    {
      "author": "Prag Swastik",
      "content": "Google recently shared five basic protective measures against coronavirus that can be followed by people worldwide. These include washing hands often, coughing into the elbow, not touching the face, staying over three feet apart from others and staying at home on feeling sick. Google engineers are also building a website to screen potential coronavirus patients in the US.",
      "date": "16 Mar 2020,Monday",
      "imageUrl": "https://static.getinpix.com/public/images/v1/variants/jpg/m/2020/03_mar/15_sun/img_1584292734587_739.jpg",
      "readMoreUrl": "https://twitter.com/Google/status/1238893403821113344?s=20&utm_campaign=fullarticle&utm_medium=referral&utm_source=inshorts ",
      "time": "07:00 am",
      "url": "https://www.inshorts.com/en/news/google-shares-5-basic-protective-measures-against-coronavirus-1584322241969"
    }
    ]`

// this is a string and i can not use .(dot notation) here
// i cannot work on string here kyuki object nahi hai
// usable js object me convert krna hoga

// i have a json string and i can not work on it directly so i need to parse it first

let obj = JSON.parse(jsonData); //accepts json string

console.log(obj[0].author);

let str = JSON.stringify(obj[0].author);
console.log(str);

