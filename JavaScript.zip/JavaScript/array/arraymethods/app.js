let arr = [1,2,3,4,5,6,'vijay', 'ajay', 'rameshwar',null,undefined,true]; // define an array
console.log(arr);

console.log(arr.length); //length of array
console.log(typeof(arr[6]));

// let arr3 = [1,2,3,4,5,6,'vijay', 'ajay',[1, 4 ,5 , 'vijay '], 'rameshwar',null,undefined,true]; // define an array
// console.log(arr3[8][1]);



// // destructive method
// let arr1 = [10,20,30];
// arr1.push(40); //it return length
// console.log(arr1);
// arr1.pop(); // it return value that we pop
// console.log(arr1);
// arr1.shift(); // it shift index and it return value that we shift
// console.log(arr1);
// arr1.unshift(22); //it add 100 st starting index and it return length
// console.log(arr1);



// let ans = [10,20,30,40,50,60,70,80,90,100];
// //slice (non-destructive)
// console.log(ans.slice(2));//it start from index 2and print till last
// console.log(ans.slice(2,4));// first is first index and second is arr.length (last index excluded)
// console.log(ans);


// //splice (destructive)
// console.log(ans.splice(3,5));//it also start from 3 index and 5 length(remove from orginal array )
// console.log(ans);

// console.log(ans.splice(3,5,'sam','ambani',30));
// console.log(ans);



// // split - only for string (non-destructive)
// let url = 'https://google.com/search/dog/best/color/black';

// let a = url. split('/');//it returns an array
// console.log(a);

// // join - array (non-destructive)
// console.log(a.join('/'));


// // concat - non-destructive -- string and array
// let arr4 = [10,20,30,40,50,60,70,80,90,100];
// let arr5 = ['sam','ram','rishu'];
// console.log(arr4.concat(arr5));
// console.log(arr5.concat(arr4));
// console.log(arr4);
// console.log(arr5);

// let str = 'vijay';
// let str1  = 'chauhan';
// console.log(str.concat(str1));


// includes -- return a boolean value --non-destructive -- string and array
// let arr6 = ['sam','ram','rishu'];
// console.log(arr6.includes('misthi'));//it check misthi in arr6


// let str2 = 'vijay';
// console.log(str2.includes('a'));


// // indexof -- string and array -- non-destructive
// let arr8 = [1,2,3,4,5,6];
// console.log(arr8.indexOf(3));

// // reverse --destructive
// let arr7 = ['sam','ram','rishu'];
// console.log(arr7.reverse());
// console.log(arr7);