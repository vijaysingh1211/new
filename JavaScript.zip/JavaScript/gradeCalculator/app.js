

function app(n){
       if(n>=95){
        return "O";

       }
       else if(n>=85 && n<95){
        return "A";
       }
       else if(n>=75 && n<85){
        return "B";
       }
       else if(n>=65 && n<75){
        return "C";
       }
       else{
        return "D";
       }
}
let n = parseInt(prompt("enter you no.="));
console.log(app(n));