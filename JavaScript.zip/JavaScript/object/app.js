let obj = {
// key -> value
   name : "vijay",
   age : 27,
   isMale : true
};
console.log(obj);
console.log(obj.name);

console.log(obj['age']);


let obj1 = obj;
console.log(obj1.name);
obj1.name = "singh";
console.log(obj1.name);
console.log(obj.name);
// object is passed by reference



