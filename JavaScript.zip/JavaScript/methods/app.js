let obj = {
    evs :90,
    cn : 80,
    web : 100,
    maths : 40,
    total : function(){  //methods
       
        return (90+90+100+40);
    }
}

console.log(obj.total());