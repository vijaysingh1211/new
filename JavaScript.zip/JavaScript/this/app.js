// basic
// let obj = {
//     naam : "vijay",
//     evs :90,
//     cn : 80,
//     web : 100,
//     maths : 40,
//     total : function(){  
//         return (this.evs + this.cn + this.web);
//     },bulao : function(){
//         return (`${this.naam} ko bulao`); //for string
//     }
// };
// console.log(obj.bulao());

// console.log(obj.total());







// this kisko point karegat ye decide hoga aapki function calling/invocation se

// 1. regular function

function vij(){
 console.log(this);
}
vij();  //it will point to window(when a js code is run a GEC is created and also a global object is created and in any browser global object is window)


// 2. method invocation

let obj = {
    number:2,
    fn : function(){
        console.log(this);
    }
}
let myfun = obj.fn(); //this is pointing to the object over which it is called




// 3. constructor fucntion calling

function Createobj(){
    this.a = 20;
}
let obje = new Createobj();
console.log(obje);
console.log(obje.a); 

// newly created object ko this point karega hamesha



// 4. .call() , .apply() , .bind()

let ob = {
    a: 20,
    fn: function(a,b,c){
        console.log(this,a,b,c);
    }
}
let ob2 = {
    a : 50
}
// ob2.fn(); //error
// ob.fn();

ob.fn.call(ob,1,2,3,4); 
ob.fn.apply(ob,[4,5,6]); 

// jab bhi tum .call() , .apply() method ka istemaal kr rhe hote ho tab jo aap call ke andar
// mention krte ho aapka this usse point krta hai  



// .bind()

let obj3 = {
    num:3,
    fn:function(){
        console.log(this);
    }
}
let myfun1 = obj3.fn.bind(obj3); //in this we fix that this point who   
myfun1(); //it always point to obj3





// 5. arrow function -> in case of array function , 'this' points to the lexical parent ka 'this'
// use for small tasks
// way - 1
// let sum = (a,b,c) => {
//     return a+b+c;
// };


// let ans = sum(10,20,30);
// console.log(ans);

// --------------------------------------------------------------------------------------
// way-2

let sum = (a,b,c) =>  a+b+c;

let ans = sum(10,20,30);
console.log(ans);

// ------------------------------------------------------------

function sqr(a){
    return a*a;
}
let sqr = (a) => {return a*a}
let sqr = (a) => a*a
let sqr  = (a)
