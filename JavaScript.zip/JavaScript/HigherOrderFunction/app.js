// function a(){
//     console.log('hi i am a');
// }


// function b(){
//     console.log('hi i am b');
// }

// a(b);
// output hi i am a
//       hi i am b




// function a(){
//     console.log('inside a');
//     function b(){
//         console.log('inside b');
//     }
//     return b;
// }
// let temp = a();
// console.log(temp);

// output
// inside a
// ƒ b(){
//         console.log('inside b');
//     }




// check my type
function getBoolean(item){
    return typeof item === 'boolean';
}
function getString(item){
    return typeof item === 'string';
}
function getNumber(item){
    return typeof item === 'number';
}



function get(array,fn){
    let result = [];
    for(let item of array){
        if(fn(item)){
            result.push(item);
        }
    }
    return result;
}

let arr = ['sam', 'samarth', 10,20,true,false,true];

console.log(get(arr , getBoolean));
console.log(get(arr , getString));
console.log(get(arr , getNumber));