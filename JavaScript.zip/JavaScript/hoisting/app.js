
// hoisting -> when you access a varible even before its declaration that concept is called hoisting
// console.log(a);
// merafunction();

// function merafunction() {
//     console.log("inside mera function");
// }

// var a =20;





// in case of let and const
console.log(a);
merafunction();
function merafunction() {
    console.log("inside mera function");
}
let a =20;

// Cannot access 'a' before initialization