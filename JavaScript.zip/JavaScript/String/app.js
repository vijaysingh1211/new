
// console.log(Number.MAX_SAFE_INTEGER);
// console.log(Number.MIN_SAFE_INTEGER);


// let str = 'i am vijay singh. i want to build an project in web development'
// let ans = str[5];
// console.log(ans);
   


// let magic = 10;
// magic = 'vijay is my name';
// console.log(magic);




// subst method
// let str = 'vijay singh is my name';
// console.log(str.substr(3)); //print from given index
// console.log(str.substr(3,7)); // first no is starting index and second is length
// console.log(str.substr(-5,4)); //if first no is -ve then it start from last




// Substring
// let str = 'vijay singh'
// console.log(str.substring(2,4)); //start from first no. and print to second no. - 1
// console.log(str.substring(4,2)); //when first index is greater then second then it reverse the value
// console.log(str.substring(-4,2)); //when first idex is -ve it becomes 0
// console.log(str.substring(-5,-2)); //both becomes 0



// indexOf
// let str = 'vijay singh'
// console.log(str.indexOf('a')); //it gives the index of given string
// console.log(str.indexOf('a',3)); //it gives the index of next a
// console.log(str.indexOf('a',str.indexOf('a'+1))); // another type of above


// replace
// let str = 'vijay singh';
// console.log(str.replace('a','m')); //replace first a to m

//replaceAll
// console.log(str.replaceAll('a','#'));//it replace all a

//repeat
// console.log(str.repeat(3));


// to uppercase
// let str = 'vijay singh';
// console.log(str.toUpperCase()); // covert to capital

// // tolowercase
// console.log(str.toLowerCase()); // covert to small letters

// // trim
// console.log(str.trim()); // remove space from start and last


