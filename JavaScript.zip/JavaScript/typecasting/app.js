// outputs typecasting
function summ(num1,num2){
    return num1 + num2;
}

// let ans = summ(10,'sam');
// console.log(typeof(ans)); //type string
// console.log(ans);

// let ans = summ(10,true);
// console.log(typeof(ans)); // type number
// console.log(ans);

// let ans = summ('100',false);
// console.log(typeof(ans)); //type string
// console.log(ans);