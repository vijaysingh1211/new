// let age = prompt("enter you age"); // user input
// prompt accepts string

parseInt(prompt("enter you age"));
// now its type is integer

