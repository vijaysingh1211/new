// event trigger undergoes three phases
// 1. event capturing -> events starts triggering from the top most level
// 2. event target -> where event trigering stops
// 3. event bubbling -> target to topmost back


let grandparent = document.getElementById('grandparent');
let parent  = document.getElementById('parent');
let child = document.getElementById('child');

// bydefault false
//  true -> callback run in capturing phase
// addEventListener('click' ,()=>{
//     console.log('grandfateher clicked !!');
// }, false) // callback run in bubbling phase

// addEventListener('click' ,()=>{
//     console.log('father clicked !!');
// }, false ) //

// addEventListener('click' ,()=>{
//     console.log('child clicked !!');
// }, false )







addEventListener('click' ,(e)=>{
    console.log('grandfateher clicked !!');
}, true) 

addEventListener('click' ,(e)=>{
    e.stopPropagation(); //it stops event here , it starts bubbling from here
    console.log('father clicked !!');

}, true)

addEventListener('click' ,(e)=>{
    console.log('child clicked !!');
}, false )